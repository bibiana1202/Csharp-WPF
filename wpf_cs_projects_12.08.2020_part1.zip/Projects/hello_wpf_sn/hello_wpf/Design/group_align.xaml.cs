﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace hello_wpf
{
    /// <summary>
    /// Interaction logic for group_align.xaml
    /// </summary>
    public partial class group_align : Window
    {
        public group_align()
        {
            InitializeComponent();
        }
    }
}
